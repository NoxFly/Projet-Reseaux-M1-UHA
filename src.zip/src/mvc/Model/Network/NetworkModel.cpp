#include "NetworkModel.hpp"

NetworkModel::NetworkModel() {

}

NetworkModel::~NetworkModel() {

}