#include "MapModel.hpp"

#include <iostream>

MapModel::MapModel():
    m_config{},
    m_tiles{}
{

}

MapModel::~MapModel() {

}

void MapModel::loadFromConfig(const MapConfig& config) {
    for(int i=1; i <= config.zoomLevel; i++) {  
        TileMap tm;

        const std::string si = std::to_string(i);
        const std::string folder = config.tileFolder + "/level_" + si;
        const std::string prefix = config.tilePrefix + si;

        std::string result = "Failed.";

        std::cout << "Loading tiles for map level " << si << "..." << std::flush;
        
        if(tm.load(folder, prefix, ".png", config.tileCountX, config.tileCountY)) {
            // std::pair<int, std::unique_ptr<TileMap>> toBeInserted = std::make_pair(i, tm);
            m_tiles.emplace(i, std::move(tm)); 
            result = "Done.";
        }

        std::cout << " " << result << std::endl;
    }
}

const TileMap& MapModel::getTilesOfLevel(uint level) {
    return m_tiles[level];
}