#ifndef NETWORK_HPP
#define NETWORK_HPP

class NetworkModel {
	public:
		NetworkModel();
		~NetworkModel();
};

#endif // NETWORK_HPP