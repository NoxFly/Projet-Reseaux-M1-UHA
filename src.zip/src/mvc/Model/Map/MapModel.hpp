#ifndef MAP_HPP
#define MAP_HPP

#include <map>
#include <memory>
#include <SFML/Graphics.hpp>

#include "config_interfaces.hpp"
#include "TileMap.hpp"

class MapModel {
	public:
		MapModel();
		~MapModel();

        void loadFromConfig(const MapConfig& config);
        const TileMap& getTilesOfLevel(uint level);

    protected:
        MapConfig m_config;
        std::map<uint, TileMap> m_tiles;
};

#endif // MAP_HPP