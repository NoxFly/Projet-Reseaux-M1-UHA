#ifndef TILEMAP_HPP
#define TILEMAP_HPP

#include <vector>
#include <memory>
#include <SFML/Graphics.hpp>


struct Tile {
    sf::Texture tex = sf::Texture();
    sf::Sprite tile = sf::Sprite();
    sf::Vector2u position = sf::Vector2u(0, 0);
};


class TileMap {
    public:
        TileMap();
        ~TileMap();

        // bool load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height);
        bool load(const std::string& tilepath, const std::string& prefix, const std::string& ext, uint width, uint height);

        const Tile& operator[](uint i);
        std::vector<Tile>::iterator begin() noexcept;
        std::vector<Tile>::iterator end() noexcept;

        const sf::Vector2u& getTileSize() const;

    protected:
        std::vector<Tile> m_tiles;
        sf::Vector2u m_tileSize;
};

#endif // TILEMAP_HPP