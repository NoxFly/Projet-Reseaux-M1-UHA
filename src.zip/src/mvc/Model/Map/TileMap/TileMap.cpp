#include "TileMap.hpp"

#include <iostream>
#include <filesystem>

#include "utils.hpp"

namespace fs = std::filesystem;


TileMap::TileMap():
    m_tiles{},
    m_tileSize(0, 0)
{
    
}

TileMap::~TileMap() {
    
}



bool TileMap::load(const std::string& tilepath, const std::string& prefix, const std::string& ext, uint width, uint height) {
    m_tiles.resize(width * height);

    for(const auto &entry : fs::directory_iterator(tilepath)) {
        Tile t;

        if(!t.tex.loadFromFile(entry.path()))
            return false;


        t.tex.setSmooth(true);
        
        const std::string prefixToRemove = tilepath + "/" + prefix + "_";
        const auto colrow = splitString(replace(replace(entry.path(), prefixToRemove, ""), ext, ""), "-");

        const uint col = std::stoi(colrow[1]);
        const uint row = (int)colrow[0][0] - 65;
        const uint index = width * row + col;

        if(!m_tileSize.x) {
            m_tileSize = t.tex.getSize();
        }


        t.tile.setTexture(t.tex);
        t.tile.setPosition(m_tileSize.x * col, m_tileSize.y * row);
        t.position.x = col;
        t.position.y = row;

        m_tiles[index] = t;//std::move(t);
    }

    return true;
}

const Tile& TileMap::operator[](uint i) {
    return m_tiles[i];
}

std::vector<Tile>::iterator TileMap::begin() noexcept {
    return m_tiles.begin();
}

std::vector<Tile>::iterator TileMap::end() noexcept {
    return m_tiles.end();
}

const sf::Vector2u& TileMap::getTileSize() const {
    return m_tileSize;
}