#include "Renderer.hpp"

#define TILE_DEBUG


#include <iostream>


Renderer::Renderer():
    m_fonts{}
{
    sf::Font font;

    std::string fontName = "Roboto";
    std::string fontPath = "res/fonts/Roboto-Bold.ttf";

    if(!font.loadFromFile(fontPath)) {
#ifdef DEBUG
        std::err << "Failed to load font " << fontPath << std::endl;
#endif
    }
    else {
        m_fonts[fontName] = font;
    }
}

Renderer::~Renderer() {
    
}

void Renderer::render(sf::RenderWindow* window, const Model& model) {
    auto tiles = model.getMap().getTilesOfLevel(1);

    for(auto t = tiles.begin(); t != tiles.end(); t++) {
        window->draw(t->tile);

#ifdef TILE_DEBUG
        sf::RectangleShape r;
        r.setSize((sf::Vector2f)tiles.getTileSize());
        r.setPosition(t->tile.getPosition());
        r.setOutlineColor(sf::Color::Red);
        r.setOutlineThickness(1);
        r.setFillColor(sf::Color::Transparent);

        window->draw(r);

        sf::Text txt;
        txt.setFont(m_fonts.at("Roboto"));
        txt.setCharacterSize(.2 * tiles.getTileSize().y);
        txt.setFillColor(sf::Color::Red);
        txt.setString(t->position.x + ", " + t->position.y);
        txt.setPosition(t->tile.getPosition());

        window->draw(txt);
#endif
    }
}