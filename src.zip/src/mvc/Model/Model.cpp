#include "Model.hpp"


Model::Model():
    m_gui(), m_map(), m_network()
{
    
}

Model::~Model() {
    
}

void Model::loadFromConfig(const AppConfig& config) {
    m_map.loadFromConfig(config.map);
}

GuiModel Model::getGui() const noexcept {
    return m_gui;
}

MapModel Model::getMap() const noexcept {
    return m_map;
}

NetworkModel Model::getNetwork() const noexcept {
    return m_network;
}