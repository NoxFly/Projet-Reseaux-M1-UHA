#ifndef GUI_HPP
#define GUI_HPP

class GuiModel {
	public:
		GuiModel();
		~GuiModel();
};

#endif // GUI_HPP