#include "GuiModel.hpp"

GuiModel::GuiModel() {

}

GuiModel::~GuiModel() {

}